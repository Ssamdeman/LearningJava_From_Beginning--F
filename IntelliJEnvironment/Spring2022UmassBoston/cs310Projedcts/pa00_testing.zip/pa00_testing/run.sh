#!/usr/bin/env bash

java -cp classes/:lib/* pa0.tests.RunTests 
