This environment provides the test suite and minimal skeleton source files that make the suite compile but fails every test. 
To run: 
1. Copy your sources to src/pa0/
2. Run ./compile.sh
3. Run ./run.sh

The results will appear in the command line. 
