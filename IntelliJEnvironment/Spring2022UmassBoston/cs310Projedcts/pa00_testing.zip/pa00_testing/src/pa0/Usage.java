//package com.gradescope.pa0;
package pa0;
// One user's record on one line: how many times
// this user has been seen on this line
public class Usage {

	public Usage(String x, int count) {
	}

	public void setCount(int x) {
	}

	public String getUser() {
	   return "NOTHING";
	}

	public int getCount() {
		return -1;
	}
}
