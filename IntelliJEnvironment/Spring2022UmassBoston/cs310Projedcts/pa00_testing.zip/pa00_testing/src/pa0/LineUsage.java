//package com.gradescope.pa0;
package pa0;


// LineUsageData.java: Handle one line's data, using a HashMap
public class LineUsage {

	public LineUsage() {
	}

	// add one sighting of a user on this line
	public void addObservation(String username) {

	}

	// find the user with the most sightings on this line
	public Usage findMaxUsage() {

		return new Usage("Nothing", -1);
	}
}
